datos=['rojo','verde','azul']
color=input('dime un color ')
if color in datos:
    print('ya está')