#actividad 2
#pide por consola 5 ciudades como destino
#almacena las ciudades como consideres
#No puede darse repetición y deben mostrarse ordenadas alfabéticamente
#el usuario puede añadir o eliminar ciudades
#1 puntos. Seleccionas la lista, set, tupla, dict... correcto y lo justificas
#1 punto. El programa funciona correctamente. añades y muestras los datos
#1 punto. Muestra los datos ordenados en orden ascendente y descendente
#1 punto. añade y elimina una ciudad
#1 punto. control de errores y validación

ciudades_list=['madrid','sevilla','valencia','madrid'] #list. Soporta sort. Admite repetición
ciudades2_tupla=('madrid','sevilla','valencia','madrid') #tupla. No soporta ordenar
ciudades3_dict={'ciudad1':'madrid','ciudad2':'sevilla','ciudad3':'valencia','ciudad4':'madrid'} #dict. No soporta ordenar
ciudades4_set={'madrid','sevilla','valencia','madrid'} #set. No repetición. No soporta sort

#Elegimos list aunque admite repetición.
try:
    ciudades=[]
    for i in range(1,6):
        ciudad=input(f'dime una ciudad {i}: ')
        if ciudad.lower() in ciudades:
            print('ya está. No se va a incluir')
        else:
            ciudades.append(ciudad.lower()) #añadir una ciudad a la lista
    ciudades.sort() #ordena alfabéticamente
    print(ciudades)
    ciudades.reverse() #ordena descendente
    print(ciudades)
    ciudades.append('coruña') #añadir una ciudad
    print(ciudades)
    ciudades.pop() #elimina una ciudad. la última
    print(ciudades)
    for ciudad in ciudades:
        print(f'La ciudad es {ciudad}')
except:
    print('algo va mal')
finally:
    print('fin del ejercio. tanto si ha ido bien como si ha ido mal')