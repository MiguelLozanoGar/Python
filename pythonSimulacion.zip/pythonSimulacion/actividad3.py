#En consola aparecen tres opciones
#1. historia
#2. matemáticas
#3. química
#el usuario debe elegir una opción.
#si la pregunta es historia, le pregunta qué animal mató a Cleopatra
#si la pregunta es matemáticas, le pregunta cuál es el seno de 90
#si lapregunta es química, le pregunta cuál es el símbolo químico del potasio
#muestra cuánto tiempo ha tardado en realizar el test
#sólo se hace una pregunta
