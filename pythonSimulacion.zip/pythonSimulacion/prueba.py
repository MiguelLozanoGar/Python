archivo=open('respuestas.txt','r')
contenido=archivo.readline()
print(contenido)

